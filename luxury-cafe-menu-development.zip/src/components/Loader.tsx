import { useEffect, useState } from "react";
import { cafeInfo } from "../data/menu";

interface LoaderProps {
  onDone: () => void;
}

export function Loader({ onDone }: LoaderProps) {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setFadeOut(true), 700);
    const t2 = setTimeout(onDone, 950);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#0a0806] transition-opacity duration-300 ${
        fadeOut ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
      role="status"
      aria-label="جاري التحميل"
    >
      <div className="relative mb-6 flex h-24 w-24 items-center justify-center">
        <div className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-[#c9a227] border-r-[#c9a227]/40" />
        <div className="absolute inset-2 rounded-full border border-[#c9a227]/20" />
        <span className="text-4xl" aria-hidden>
          ☕
        </span>
      </div>
      <h1 className="font-cairo text-2xl font-bold tracking-wide text-[#f5f0e8]">
        {cafeInfo.name}
      </h1>
      <p className="mt-2 font-cairo text-sm text-[#a89f91]">{cafeInfo.nameEn}</p>
    </div>
  );
}

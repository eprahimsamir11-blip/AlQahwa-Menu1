import { cafeInfo } from "../data/menu";

interface HeroProps {
  onStart: () => void;
}

export function Hero({ onStart }: HeroProps) {
  return (
    <header className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-6 py-16 text-center">
      {/* خلفية متدرجة مع ضوء ذهبي */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0806] via-[#14100c] to-[#0a0806]" />
        <div className="absolute top-1/4 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#c9a227]/[0.07] blur-[100px]" />
        <div className="absolute right-0 bottom-1/4 h-64 w-64 rounded-full bg-[#6b4226]/20 blur-[80px]" />
        <div className="absolute top-0 left-0 h-px w-full bg-gradient-to-l from-transparent via-[#c9a227]/30 to-transparent" />
      </div>

      <div className="relative z-10 flex max-w-lg flex-col items-center animate-fade-in">
        {/* الشعار */}
        <div className="mb-8 flex h-28 w-28 items-center justify-center rounded-full border border-[#c9a227]/30 bg-gradient-to-br from-[#1a1410] to-[#0f0c09] shadow-[0_0_40px_rgba(201,162,39,0.15)]">
          <div className="flex h-24 w-24 items-center justify-center rounded-full border border-[#c9a227]/15 bg-[#0a0806]">
            <span className="text-5xl" aria-hidden>
              ☕
            </span>
          </div>
        </div>

        <p className="mb-3 font-cairo text-xs font-medium tracking-[0.35em] text-[#c9a227] uppercase">
          {cafeInfo.nameEn}
        </p>

        <h1 className="font-cairo text-4xl font-bold leading-tight text-[#f5f0e8] sm:text-5xl">
          {cafeInfo.name}
        </h1>

        <div className="my-5 h-px w-16 bg-gradient-to-l from-transparent via-[#c9a227] to-transparent" />

        <p className="mb-10 max-w-xs font-cairo text-base leading-relaxed text-[#a89f91]">
          {cafeInfo.tagline}
        </p>

        <p className="mb-8 font-cairo text-sm text-[#7a7268]">
          أهلاً بك · اختر مشروبك المفضل
        </p>

        <button
          type="button"
          onClick={onStart}
          className="group relative overflow-hidden rounded-full bg-gradient-to-l from-[#c9a227] to-[#a8861f] px-10 py-4 font-cairo text-base font-bold text-[#0a0806] shadow-[0_8px_30px_rgba(201,162,39,0.35)] transition-all duration-300 active:scale-[0.97] hover:shadow-[0_10px_40px_rgba(201,162,39,0.45)]"
        >
          <span className="relative z-10">ابدأ تصفح المنيو</span>
          <span
            className="absolute inset-0 -translate-x-full bg-gradient-to-l from-white/20 to-transparent transition-transform duration-500 group-hover:translate-x-0"
            aria-hidden
          />
        </button>

        {/* سهم التمرير */}
        <button
          type="button"
          onClick={onStart}
          className="mt-14 animate-bounce text-[#c9a227]/50 transition-colors hover:text-[#c9a227]"
          aria-label="انتقل للمنيو"
        >
          <svg
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
      </div>
    </header>
  );
}

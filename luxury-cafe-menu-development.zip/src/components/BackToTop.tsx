interface BackToTopProps {
  visible: boolean;
}

export function BackToTop({ visible }: BackToTopProps) {
  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      type="button"
      onClick={scrollTop}
      className={`fixed bottom-6 left-6 z-50 flex h-12 w-12 items-center justify-center rounded-full border border-[#c9a227]/30 bg-[#14100c]/95 text-[#c9a227] shadow-[0_4px_20px_rgba(0,0,0,0.4)] backdrop-blur-sm transition-all duration-300 active:scale-95 hover:border-[#c9a227]/60 hover:bg-[#1a1410] hover:shadow-[0_6px_24px_rgba(201,162,39,0.2)] ${
        visible
          ? "translate-y-0 opacity-100"
          : "pointer-events-none translate-y-4 opacity-0"
      }`}
      aria-label="العودة للأعلى"
    >
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
      </svg>
    </button>
  );
}

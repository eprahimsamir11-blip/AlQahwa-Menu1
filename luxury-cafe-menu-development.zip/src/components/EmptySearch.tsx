export function EmptySearch({ query }: { query: string }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-16 text-center animate-fade-in">
      <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-[#14100c] ring-1 ring-[#2a241c]">
        <span className="text-4xl" aria-hidden>
          🔍
        </span>
      </div>
      <h3 className="font-cairo text-lg font-bold text-[#f5f0e8]">
        لا توجد نتائج
      </h3>
      <p className="mt-2 max-w-xs font-cairo text-sm leading-relaxed text-[#7a7268]">
        لم نجد أي صنف يطابق «{query}». جرّب كلمة أخرى أو تصفّح الأقسام.
      </p>
    </div>
  );
}

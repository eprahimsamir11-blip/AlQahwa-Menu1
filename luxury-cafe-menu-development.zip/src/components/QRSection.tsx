import { useCallback, useRef, useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { cafeInfo, MENU_URL } from "../data/menu";

export function QRSection() {
  const canvasWrapRef = useRef<HTMLDivElement>(null);
  const [shareMsg, setShareMsg] = useState("");

  const downloadQR = useCallback(() => {
    const canvas = canvasWrapRef.current?.querySelector("canvas");
    if (!canvas) return;

    // إنشاء canvas أكبر مع خلفية بيضاء للطباعة
    const size = 512;
    const out = document.createElement("canvas");
    out.width = size;
    out.height = size + 80;
    const ctx = out.getContext("2d");
    if (!ctx) return;

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, out.width, out.height);

    const pad = 40;
    ctx.drawImage(canvas, pad, pad, size - pad * 2, size - pad * 2);

    ctx.fillStyle = "#0a0806";
    ctx.font = "bold 22px Cairo, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(cafeInfo.name, size / 2, size + 20);
    ctx.font = "14px Cairo, sans-serif";
    ctx.fillStyle = "#666";
    ctx.fillText("امسح الكود لفتح المنيو", size / 2, size + 48);

    const link = document.createElement("a");
    link.download = "alqahwa-cafe-qr.png";
    link.href = out.toDataURL("image/png");
    link.click();
  }, []);

  const shareMenu = useCallback(async () => {
    const shareData = {
      title: cafeInfo.name,
      text: `تصفّح منيو ${cafeInfo.name}`,
      url: MENU_URL,
    };

    try {
      if (navigator.share && navigator.canShare?.(shareData)) {
        await navigator.share(shareData);
        return;
      }
    } catch {
      /* المستخدم ألغى المشاركة */
    }

    try {
      await navigator.clipboard.writeText(MENU_URL);
      setShareMsg("تم نسخ الرابط!");
    } catch {
      setShareMsg(MENU_URL);
    }
    setTimeout(() => setShareMsg(""), 2500);
  }, []);

  return (
    <section
      id="qr"
      className="mx-auto max-w-2xl px-4 py-12 sm:px-6"
      aria-labelledby="qr-title"
    >
      <div className="relative overflow-hidden rounded-3xl border border-[#c9a227]/20 bg-gradient-to-b from-[#1a1410] to-[#0f0c09] p-8 text-center shadow-[0_20px_60px_rgba(0,0,0,0.4)]">
        <div
          className="pointer-events-none absolute top-0 left-1/2 h-32 w-64 -translate-x-1/2 rounded-full bg-[#c9a227]/10 blur-3xl"
          aria-hidden
        />

        <h2
          id="qr-title"
          className="relative font-cairo text-xl font-bold text-[#f5f0e8] sm:text-2xl"
        >
          امسح الكود لفتح المنيو
        </h2>
        <p className="relative mt-2 font-cairo text-sm text-[#7a7268]">
          جاهز للطباعة على الطاولات
        </p>

        <div
          ref={canvasWrapRef}
          className="relative mx-auto mt-8 flex w-fit items-center justify-center rounded-2xl bg-white p-4 shadow-lg"
        >
          <QRCodeCanvas
            value={MENU_URL}
            size={200}
            level="H"
            bgColor="#ffffff"
            fgColor="#0a0806"
            includeMargin={false}
          />
        </div>

        <p className="relative mt-4 font-cairo text-xs text-[#5c554c] break-all" dir="ltr">
          {MENU_URL}
        </p>

        <div className="relative mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <button
            type="button"
            onClick={downloadQR}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-l from-[#c9a227] to-[#a8861f] px-6 py-3.5 font-cairo text-sm font-bold text-[#0a0806] transition-all duration-300 active:scale-[0.97] hover:shadow-[0_6px_24px_rgba(201,162,39,0.35)]"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5 5-5M12 15V3" />
            </svg>
            تحميل QR Code
          </button>

          <button
            type="button"
            onClick={shareMenu}
            className="inline-flex items-center justify-center gap-2 rounded-full border border-[#c9a227]/40 bg-transparent px-6 py-3.5 font-cairo text-sm font-bold text-[#c9a227] transition-all duration-300 active:scale-[0.97] hover:bg-[#c9a227]/10"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
            مشاركة رابط المنيو
          </button>
        </div>

        {shareMsg && (
          <p className="relative mt-4 font-cairo text-sm text-[#c9a227] animate-fade-in">
            {shareMsg}
          </p>
        )}
      </div>
    </section>
  );
}

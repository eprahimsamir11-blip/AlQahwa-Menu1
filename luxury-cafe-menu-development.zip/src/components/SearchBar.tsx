interface SearchBarProps {
  query: string;
  onChange: (value: string) => void;
}

export function SearchBar({ query, onChange }: SearchBarProps) {
  return (
    <div className="sticky top-0 z-40 bg-[#0a0806]/90 px-4 py-3 backdrop-blur-md sm:px-6">
      <div className="relative mx-auto max-w-2xl">
        <div className="pointer-events-none absolute inset-y-0 right-4 flex items-center">
          <svg
            className="h-5 w-5 text-[#7a7268]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.8}
            aria-hidden
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
            />
          </svg>
        </div>

        <input
          type="search"
          value={query}
          onChange={(e) => onChange(e.target.value)}
          placeholder="ابحث عن مشروب أو صنف..."
          className="w-full rounded-2xl border border-[#2a241c] bg-[#14100c] py-3.5 pr-12 pl-12 font-cairo text-base text-[#f5f0e8] placeholder:text-[#5c554c] outline-none transition-all duration-300 focus:border-[#c9a227]/50 focus:shadow-[0_0_0_3px_rgba(201,162,39,0.12)]"
          aria-label="البحث في المنيو"
          autoComplete="off"
          enterKeyHint="search"
        />

        {query && (
          <button
            type="button"
            onClick={() => onChange("")}
            className="absolute inset-y-0 left-3 flex items-center rounded-full p-1.5 text-[#7a7268] transition-colors duration-200 hover:text-[#f5f0e8]"
            aria-label="مسح البحث"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
}

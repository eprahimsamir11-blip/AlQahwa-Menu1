import { useRef, useEffect, useState } from "react";
import type { MenuCategory } from "../types/menu";
import { ProductCard } from "./ProductCard";
import { toArabicDigits } from "../utils/format";
import { cn } from "../utils/cn";

interface CategoryAccordionProps {
  category: MenuCategory;
  isOpen: boolean;
  onToggle: () => void;
  searchQuery?: string;
}

export function CategoryAccordion({
  category,
  isOpen,
  onToggle,
  searchQuery = "",
}: CategoryAccordionProps) {
  const contentRef = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState(0);

  const items = searchQuery
    ? category.items.filter((item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : category.items;

  useEffect(() => {
    if (contentRef.current) {
      setHeight(isOpen ? contentRef.current.scrollHeight : 0);
    }
  }, [isOpen, items.length, searchQuery]);

  if (searchQuery && items.length === 0) return null;

  return (
    <section className="overflow-hidden rounded-2xl border border-[#2a241c] bg-[#100d0a] transition-shadow duration-300">
      <button
        type="button"
        onClick={onToggle}
        className={cn(
          "flex w-full items-center gap-4 px-5 py-5 text-right transition-all duration-300",
          isOpen
            ? "bg-gradient-to-l from-[#1a1410] to-[#14100c]"
            : "hover:bg-[#14100c] active:bg-[#1a1410]"
        )}
        aria-expanded={isOpen}
      >
        <span
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#1a1410] text-2xl shadow-inner ring-1 ring-[#c9a227]/10"
          aria-hidden
        >
          {category.icon}
        </span>

        <div className="min-w-0 flex-1">
          <h2 className="font-cairo text-lg font-bold text-[#f5f0e8]">
            {category.name}
          </h2>
          <p className="mt-0.5 font-cairo text-xs text-[#7a7268]">
            {toArabicDigits(items.length)}{" "}
            {items.length === 1 ? "صنف" : "أصناف"}
          </p>
        </div>

        <svg
          className={cn(
            "h-5 w-5 shrink-0 text-[#c9a227] transition-transform duration-300",
            isOpen && "rotate-180"
          )}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
          aria-hidden
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      <div
        className="overflow-hidden transition-[height] duration-300 ease-in-out"
        style={{ height }}
      >
        <div ref={contentRef} className="space-y-2.5 px-4 pt-1 pb-5">
          {items.map((item, i) => (
            <ProductCard key={item.id} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

interface ScrollProgressProps {
  progress: number;
}

export function ScrollProgress({ progress }: ScrollProgressProps) {
  return (
    <div
      className="fixed top-0 right-0 left-0 z-50 h-[3px] bg-transparent"
      aria-hidden
    >
      <div
        className="h-full origin-right bg-gradient-to-l from-[#c9a227] via-[#e8d48b] to-[#c9a227] transition-[width] duration-150 ease-out"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

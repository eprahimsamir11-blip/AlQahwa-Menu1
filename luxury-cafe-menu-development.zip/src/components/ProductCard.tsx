import { useState } from "react";
import type { MenuItem } from "../types/menu";
import { formatPrice } from "../utils/format";
import { cn } from "../utils/cn";

interface ProductCardProps {
  item: MenuItem;
  index?: number;
}

export function ProductCard({ item, index = 0 }: ProductCardProps) {
  const [pressed, setPressed] = useState(false);

  return (
    <article
      className={cn(
        "group relative flex items-center justify-between gap-3 rounded-2xl border border-[#2a241c] bg-[#14100c] px-4 py-4 transition-all duration-300",
        "hover:border-[#c9a227]/25 hover:bg-[#1a1410]",
        "active:scale-[0.98]",
        pressed && "border-[#c9a227]/40 bg-[#1c1610] shadow-[0_0_20px_rgba(201,162,39,0.08)]",
        "animate-slide-up"
      )}
      style={{ animationDelay: `${Math.min(index * 40, 400)}ms` }}
      onPointerDown={() => setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
    >
      <div className="min-w-0 flex-1 text-right">
        <div className="flex items-center gap-2">
          <h3 className="font-cairo text-base font-semibold text-[#f5f0e8] transition-colors duration-200 group-hover:text-white">
            {item.name}
          </h3>
          {item.popular && (
            <span className="shrink-0 rounded-full bg-[#c9a227]/15 px-2 py-0.5 font-cairo text-[10px] font-medium text-[#c9a227]">
              الأكثر طلباً
            </span>
          )}
        </div>
        {item.description && (
          <p className="mt-1 font-cairo text-xs leading-relaxed text-[#7a7268]">
            {item.description}
          </p>
        )}
      </div>

      <span className="shrink-0 rounded-full bg-gradient-to-l from-[#c9a227] to-[#b8941f] px-3.5 py-1.5 font-cairo text-sm font-bold text-[#0a0806] shadow-[0_2px_10px_rgba(201,162,39,0.25)]">
        {formatPrice(item.price)}
      </span>
    </article>
  );
}

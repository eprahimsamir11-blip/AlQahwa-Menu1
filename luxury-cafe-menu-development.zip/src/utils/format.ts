/** تحويل الأرقام الإنجليزية إلى عربية هندية */
export function toArabicDigits(value: number | string): string {
  const str = String(value);
  return str.replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);
}

/** تنسيق السعر بالجنيه */
export function formatPrice(price: number): string {
  return `${toArabicDigits(price)} جنيه`;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description?: string;
  popular?: boolean;
  tags?: string[];
}

export interface MenuCategory {
  id: string;
  name: string;
  icon: string;
  items: MenuItem[];
}

export interface CafeInfo {
  name: string;
  nameEn: string;
  tagline: string;
  phone: string;
  address: string;
  menuUrl: string;
  social: {
    instagram?: string;
    facebook?: string;
    whatsapp?: string;
  };
}

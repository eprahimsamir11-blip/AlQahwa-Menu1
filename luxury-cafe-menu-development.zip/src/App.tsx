import { useCallback, useMemo, useRef, useState } from "react";
import { menuCategories } from "./data/menu";
import { useScrollProgress } from "./hooks/useScrollProgress";
import { Loader } from "./components/Loader";
import { ScrollProgress } from "./components/ScrollProgress";
import { Hero } from "./components/Hero";
import { SearchBar } from "./components/SearchBar";
import { CategoryAccordion } from "./components/CategoryAccordion";
import { EmptySearch } from "./components/EmptySearch";
import { QRSection } from "./components/QRSection";
import { Footer } from "./components/Footer";
import { BackToTop } from "./components/BackToTop";

export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const menuRef = useRef<HTMLElement>(null);
  const { progress, showTop } = useScrollProgress();

  const handleLoaded = useCallback(() => setLoaded(true), []);

  const scrollToMenu = useCallback(() => {
    menuRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const handleToggle = useCallback((id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  }, []);

  const hasResults = useMemo(() => {
    if (!query.trim()) return true;
    const q = query.trim().toLowerCase();
    return menuCategories.some((cat) =>
      cat.items.some((item) => item.name.toLowerCase().includes(q))
    );
  }, [query]);

  const isSearching = Boolean(query.trim());

  return (
    <div className="min-h-screen bg-[#0a0806] text-[#f5f0e8]" dir="rtl">
      {!loaded && <Loader onDone={handleLoaded} />}

      <ScrollProgress progress={progress} />

      <Hero onStart={scrollToMenu} />

      <main ref={menuRef} id="menu" className="relative">
        <SearchBar query={query} onChange={setQuery} />

        <div className="mx-auto max-w-2xl space-y-3 px-4 py-6 sm:px-6">
          <div className="mb-4 flex items-center justify-between px-1">
            <h2 className="font-cairo text-sm font-medium tracking-wide text-[#7a7268]">
              {isSearching ? "نتائج البحث" : "أقسام المنيو"}
            </h2>
            {!isSearching && (
              <span className="font-cairo text-xs text-[#5c554c]">
                اضغط لفتح القسم
              </span>
            )}
          </div>

          {!hasResults && isSearching ? (
            <EmptySearch query={query.trim()} />
          ) : (
            menuCategories.map((category) => (
              <CategoryAccordion
                key={category.id}
                category={category}
                isOpen={isSearching || openId === category.id}
                onToggle={() => {
                  if (!isSearching) handleToggle(category.id);
                }}
                searchQuery={query.trim()}
              />
            ))
          )}
        </div>

        <QRSection />
      </main>

      <Footer />
      <BackToTop visible={showTop} />
    </div>
  );
}

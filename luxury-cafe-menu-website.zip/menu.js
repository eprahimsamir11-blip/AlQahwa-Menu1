/**
 * ع القهوة كافيه - ملف المنتجات
 * لتعديل الأسعار أو إضافة منتجات: عدّل هذا الملف فقط
 * price بالـ جنيه المصري (ج.م)
 */

const MENU_DATA = [
  {
    id: "hot-drinks",
    name: "المشروبات الساخنة",
    icon: "☕",
    items: [
      { id: "h1", name: "إسبريسو", price: 35 },
      { id: "h2", name: "دوبل إسبريسو", price: 45 },
      { id: "h3", name: "أمريكانو", price: 40 },
      { id: "h4", name: "كورتادو", price: 45 },
      { id: "h5", name: "كابتشينو", price: 50 },
      { id: "h6", name: "لاتيه", price: 55 },
      { id: "h7", name: "فلات وايت", price: 55 },
      { id: "h8", name: "موكا", price: 60 },
      { id: "h9", name: "ماكياتو", price: 50 },
      { id: "h10", name: "قهوة تركي", price: 30 },
      { id: "h11", name: "قهوة تركي دوبل", price: 40 },
      { id: "h12", name: "قهوة فرنساوي", price: 45 },
      { id: "h13", name: "نسكافيه", price: 35 },
      { id: "h14", name: "هوت شوكليت", price: 50 },
      { id: "h15", name: "شاي أحمر", price: 20 },
      { id: "h16", name: "شاي أخضر", price: 25 },
      { id: "h17", name: "ينسون", price: 25 },
      { id: "h18", name: "نعناع", price: 25 },
      { id: "h19", name: "كركديه", price: 25 },
      { id: "h20", name: "قرفة بالحليب", price: 40 }
    ]
  },
  {
    id: "cold-drinks",
    name: "المشروبات الباردة",
    icon: "🧊",
    items: [
      { id: "c1", name: "آيس كوفي", price: 50 },
      { id: "c2", name: "آيس لاتيه", price: 55 },
      { id: "c3", name: "آيس أمريكانو", price: 45 },
      { id: "c4", name: "آيس موكا", price: 60 },
      { id: "c5", name: "آيس كابتشينو", price: 55 },
      { id: "c6", name: "كولد برو", price: 65 },
      { id: "c7", name: "أفوجاتو", price: 70 },
      { id: "c8", name: "فرابيه كراميل", price: 65 },
      { id: "c9", name: "فرابيه فانيليا", price: 65 },
      { id: "c10", name: "سبانيش لاتيه مثلج", price: 70 },
      { id: "c11", name: "موكا بندق مثلج", price: 70 },
      { id: "c12", name: "ليمون بالنعناع", price: 40 },
      { id: "c13", name: "صودا ليمون", price: 35 },
      { id: "c14", name: "مياه معدنية", price: 15 },
      { id: "c15", name: "مياه غازية", price: 20 }
    ]
  },
  {
    id: "milkshake",
    name: "الميلك شيك",
    icon: "🥤",
    items: [
      { id: "m1", name: "ميلك شيك فانيليا", price: 60 },
      { id: "m2", name: "ميلك شيك شوكولاتة", price: 65 },
      { id: "m3", name: "ميلك شيك فراولة", price: 65 },
      { id: "m4", name: "ميلك شيك أوريو", price: 70 },
      { id: "m5", name: "ميلك شيك كراميل", price: 70 },
      { id: "m6", name: "ميلك شيك لوتس", price: 75 },
      { id: "m7", name: "ميلك شيك نوتيلا", price: 75 },
      { id: "m8", name: "ميلك شيك موز", price: 60 },
      { id: "m9", name: "ميلك شيك مانجو", price: 70 },
      { id: "m10", name: "ميلك شيك توت", price: 75 }
    ]
  },
  {
    id: "mojito",
    name: "الموهيتو",
    icon: "🌿",
    items: [
      { id: "mo1", name: "موهيتو كلاسيك", price: 50 },
      { id: "mo2", name: "موهيتو فراولة", price: 55 },
      { id: "mo3", name: "موهيتو توت", price: 55 },
      { id: "mo4", name: "موهيتو مانجو", price: 55 },
      { id: "mo5", name: "موهيتو باشن فروت", price: 60 },
      { id: "mo6", name: "موهيتو أناناس", price: 55 },
      { id: "mo7", name: "موهيتو خوخ", price: 55 },
      { id: "mo8", name: "موهيتو بلو بيري", price: 60 },
      { id: "mo9", name: "موهيتو رمان", price: 55 },
      { id: "mo10", name: "موهيتو كيوي", price: 60 }
    ]
  },
  {
    id: "fresh-juices",
    name: "العصائر الفريش",
    icon: "🍊",
    items: [
      { id: "j1", name: "عصير برتقال", price: 40 },
      { id: "j2", name: "عصير مانجو", price: 50 },
      { id: "j3", name: "عصير فراولة", price: 45 },
      { id: "j4", name: "عصير جوافة", price: 40 },
      { id: "j5", name: "عصير أناناس", price: 45 },
      { id: "j6", name: "عصير ليمون", price: 35 },
      { id: "j7", name: "عصير كانتلوب", price: 40 },
      { id: "j8", name: "عصير بطيخ", price: 40 },
      { id: "j9", name: "عصير رمان", price: 55 },
      { id: "j10", name: "كوكتيل فواكه", price: 55 },
      { id: "j11", name: "موز بلبن", price: 45 },
      { id: "j12", name: "أفوكادو", price: 60 },
      { id: "j13", name: "سموثي فراولة", price: 55 },
      { id: "j14", name: "سموثي مانجو", price: 55 }
    ]
  },
  {
    id: "desserts",
    name: "الحلويات",
    icon: "🍰",
    items: [
      { id: "d1", name: "تشيز كيك", price: 65 },
      { id: "d2", name: "تشيز كيك لوتس", price: 75 },
      { id: "d3", name: "براوني", price: 55 },
      { id: "d4", name: "تيراميسو", price: 70 },
      { id: "d5", name: "كنافة نوتيلا", price: 70 },
      { id: "d6", name: "وافل", price: 60 },
      { id: "d7", name: "بان كيك", price: 55 },
      { id: "d8", name: "كرواسون سادة", price: 35 },
      { id: "d9", name: "كرواسون شوكولاتة", price: 45 },
      { id: "d10", name: "دونات", price: 40 },
      { id: "d11", name: "كوكيز", price: 30 },
      { id: "d12", name: "آيس كريم كوب", price: 40 },
      { id: "d13", name: "أم علي", price: 50 },
      { id: "d14", name: "بسبوسة", price: 35 }
    ]
  },
  {
    id: "food",
    name: "الأكلات",
    icon: "🍽️",
    items: [
      { id: "f1", name: "كرواسون جبنة", price: 50 },
      { id: "f2", name: "كرواسون تركي", price: 60 },
      { id: "f3", name: "ساندوتش تونة", price: 55 },
      { id: "f4", name: "ساندوتش رومي مدخن", price: 65 },
      { id: "f5", name: "ساندوتش دجاج", price: 70 },
      { id: "f6", name: "كلوب ساندوتش", price: 85 },
      { id: "f7", name: "برجر لحم", price: 90 },
      { id: "f8", name: "برجر دجاج", price: 80 },
      { id: "f9", name: "بطاطس مقلية", price: 40 },
      { id: "f10", name: "بطاطس ويدجز", price: 45 },
      { id: "f11", name: "ناجتس دجاج", price: 55 },
      { id: "f12", name: "سلطة سيزر", price: 70 },
      { id: "f13", name: "سلطة يوناني", price: 60 },
      { id: "f14", name: "أومليت جبنة", price: 50 },
      { id: "f15", name: "شكشوكة", price: 55 },
      { id: "f16", name: "فول وطعمية", price: 40 },
      { id: "f17", name: "بيض مسلوق", price: 30 },
      { id: "f18", name: "توست جبنة رومي", price: 45 }
    ]
  }
];
